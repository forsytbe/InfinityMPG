/** Automatically generated file. DO NOT MODIFY */
package com.devsyte.infinitympg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}